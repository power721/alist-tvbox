// 玩偶哥哥(盘) OpenCat 版——与 CatVodOpen nodejs 工程的 wogg.js 同源逻辑
// (参照 atv-spiders/py/玩偶哥哥.py):多域名容灾 + 卡片解析 + 盘线路透传。
import { load, _ } from 'assets://js/lib/cat.js';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36';

const CATEGORIES = [
    {type_id: '44', type_name: '臻彩视界'},
    {type_id: '1', type_name: '玩偶电影'},
    {type_id: '2', type_name: '玩偶剧集'},
    {type_id: '3', type_name: '玩偶动漫'},
    {type_id: '4', type_name: '玩偶综艺'},
    {type_id: '6', type_name: '玩偶短剧'},
    {type_id: '5', type_name: '玩偶音乐'},
    {type_id: '46', type_name: '玩偶纪录'},
];

const FILTERS = {
  "1": [
    {
      "key": "class",
      "name": "剧情",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "喜剧",
          "v": "喜剧"
        },
        {
          "n": "爱情",
          "v": "爱情"
        },
        {
          "n": "恐怖",
          "v": "恐怖"
        },
        {
          "n": "动作",
          "v": "动作"
        },
        {
          "n": "科幻",
          "v": "科幻"
        },
        {
          "n": "剧情",
          "v": "剧情"
        },
        {
          "n": "战争",
          "v": "战争"
        },
        {
          "n": "警匪",
          "v": "警匪"
        },
        {
          "n": "犯罪",
          "v": "犯罪"
        },
        {
          "n": "动画",
          "v": "动画"
        },
        {
          "n": "奇幻",
          "v": "奇幻"
        },
        {
          "n": "武侠",
          "v": "武侠"
        },
        {
          "n": "冒险",
          "v": "冒险"
        },
        {
          "n": "枪战",
          "v": "枪战"
        },
        {
          "n": "悬疑",
          "v": "悬疑"
        },
        {
          "n": "惊悚",
          "v": "惊悚"
        },
        {
          "n": "经典",
          "v": "经典"
        },
        {
          "n": "青春",
          "v": "青春"
        },
        {
          "n": "文艺",
          "v": "文艺"
        },
        {
          "n": "微电影",
          "v": "微电影"
        },
        {
          "n": "古装",
          "v": "古装"
        },
        {
          "n": "历史",
          "v": "历史"
        },
        {
          "n": "运动",
          "v": "运动"
        },
        {
          "n": "农村",
          "v": "农村"
        },
        {
          "n": "儿童",
          "v": "儿童"
        },
        {
          "n": "网络电影",
          "v": "网络电影"
        }
      ]
    },
    {
      "key": "area",
      "name": "地区",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "大陆",
          "v": "大陆"
        },
        {
          "n": "香港",
          "v": "香港"
        },
        {
          "n": "台湾",
          "v": "台湾"
        },
        {
          "n": "美国",
          "v": "美国"
        },
        {
          "n": "法国",
          "v": "法国"
        },
        {
          "n": "英国",
          "v": "英国"
        },
        {
          "n": "日本",
          "v": "日本"
        },
        {
          "n": "韩国",
          "v": "韩国"
        },
        {
          "n": "德国",
          "v": "德国"
        },
        {
          "n": "泰国",
          "v": "泰国"
        },
        {
          "n": "印度",
          "v": "印度"
        },
        {
          "n": "意大利",
          "v": "意大利"
        },
        {
          "n": "西班牙",
          "v": "西班牙"
        },
        {
          "n": "加拿大",
          "v": "加拿大"
        },
        {
          "n": "其他",
          "v": "其他"
        }
      ]
    },
    {
      "key": "year",
      "name": "年份",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "2026",
          "v": "2026"
        },
        {
          "n": "2025",
          "v": "2025"
        },
        {
          "n": "2024",
          "v": "2024"
        },
        {
          "n": "2023",
          "v": "2023"
        },
        {
          "n": "2022",
          "v": "2022"
        },
        {
          "n": "2021",
          "v": "2021"
        },
        {
          "n": "2020",
          "v": "2020"
        },
        {
          "n": "2019",
          "v": "2019"
        },
        {
          "n": "2018",
          "v": "2018"
        },
        {
          "n": "2017",
          "v": "2017"
        },
        {
          "n": "2016",
          "v": "2016"
        },
        {
          "n": "2015",
          "v": "2015"
        },
        {
          "n": "2014",
          "v": "2014"
        },
        {
          "n": "2013",
          "v": "2013"
        },
        {
          "n": "2012",
          "v": "2012"
        },
        {
          "n": "2011",
          "v": "2011"
        },
        {
          "n": "2010",
          "v": "2010"
        },
        {
          "n": "2009",
          "v": "2009"
        },
        {
          "n": "2008",
          "v": "2008"
        },
        {
          "n": "2007",
          "v": "2007"
        },
        {
          "n": "2006",
          "v": "2006"
        }
      ]
    },
    {
      "key": "by",
      "name": "排序",
      "init": "time",
      "value": [
        {
          "n": "时间",
          "v": "time"
        },
        {
          "n": "人气",
          "v": "hits"
        },
        {
          "n": "评分",
          "v": "score"
        }
      ]
    }
  ],
  "2": [
    {
      "key": "class",
      "name": "剧情",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "古装",
          "v": "古装"
        },
        {
          "n": "战争",
          "v": "战争"
        },
        {
          "n": "青春偶像",
          "v": "青春偶像"
        },
        {
          "n": "喜剧",
          "v": "喜剧"
        },
        {
          "n": "家庭",
          "v": "家庭"
        },
        {
          "n": "犯罪",
          "v": "犯罪"
        },
        {
          "n": "动作",
          "v": "动作"
        },
        {
          "n": "奇幻",
          "v": "奇幻"
        },
        {
          "n": "剧情",
          "v": "剧情"
        },
        {
          "n": "历史",
          "v": "历史"
        },
        {
          "n": "经典",
          "v": "经典"
        },
        {
          "n": "乡村",
          "v": "乡村"
        },
        {
          "n": "情景",
          "v": "情景"
        },
        {
          "n": "商战",
          "v": "商战"
        },
        {
          "n": "网剧",
          "v": "网剧"
        },
        {
          "n": "其他",
          "v": "其他"
        }
      ]
    },
    {
      "key": "area",
      "name": "地区",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "内地",
          "v": "内地"
        },
        {
          "n": "韩国",
          "v": "韩国"
        },
        {
          "n": "香港",
          "v": "香港"
        },
        {
          "n": "台湾",
          "v": "台湾"
        },
        {
          "n": "日本",
          "v": "日本"
        },
        {
          "n": "美国",
          "v": "美国"
        },
        {
          "n": "泰国",
          "v": "泰国"
        },
        {
          "n": "英国",
          "v": "英国"
        },
        {
          "n": "新加坡",
          "v": "新加坡"
        },
        {
          "n": "其他",
          "v": "其他"
        }
      ]
    },
    {
      "key": "year",
      "name": "年份",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "2026",
          "v": "2026"
        },
        {
          "n": "2025",
          "v": "2025"
        },
        {
          "n": "2024",
          "v": "2024"
        },
        {
          "n": "2023",
          "v": "2023"
        },
        {
          "n": "2022",
          "v": "2022"
        },
        {
          "n": "2021",
          "v": "2021"
        },
        {
          "n": "2020",
          "v": "2020"
        },
        {
          "n": "2019",
          "v": "2019"
        },
        {
          "n": "2018",
          "v": "2018"
        },
        {
          "n": "2017",
          "v": "2017"
        },
        {
          "n": "2016",
          "v": "2016"
        },
        {
          "n": "2015",
          "v": "2015"
        },
        {
          "n": "2014",
          "v": "2014"
        },
        {
          "n": "2013",
          "v": "2013"
        },
        {
          "n": "2012",
          "v": "2012"
        },
        {
          "n": "2011",
          "v": "2011"
        },
        {
          "n": "2010",
          "v": "2010"
        },
        {
          "n": "2009",
          "v": "2009"
        },
        {
          "n": "2008",
          "v": "2008"
        },
        {
          "n": "2007",
          "v": "2007"
        },
        {
          "n": "2006",
          "v": "2006"
        }
      ]
    },
    {
      "key": "by",
      "name": "排序",
      "init": "time",
      "value": [
        {
          "n": "时间",
          "v": "time"
        },
        {
          "n": "人气",
          "v": "hits"
        },
        {
          "n": "评分",
          "v": "score"
        }
      ]
    }
  ],
  "3": [
    {
      "key": "class",
      "name": "剧情",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "情感",
          "v": "情感"
        },
        {
          "n": "科幻",
          "v": "科幻"
        },
        {
          "n": "热血",
          "v": "热血"
        },
        {
          "n": "推理",
          "v": "推理"
        },
        {
          "n": "搞笑",
          "v": "搞笑"
        },
        {
          "n": "冒险",
          "v": "冒险"
        },
        {
          "n": "萝莉",
          "v": "萝莉"
        },
        {
          "n": "校园",
          "v": "校园"
        },
        {
          "n": "动作",
          "v": "动作"
        },
        {
          "n": "机战",
          "v": "机战"
        },
        {
          "n": "运动",
          "v": "运动"
        },
        {
          "n": "战争",
          "v": "战争"
        },
        {
          "n": "少年",
          "v": "少年"
        },
        {
          "n": "少女",
          "v": "少女"
        },
        {
          "n": "社会",
          "v": "社会"
        },
        {
          "n": "原创",
          "v": "原创"
        },
        {
          "n": "亲子",
          "v": "亲子"
        },
        {
          "n": "益智",
          "v": "益智"
        },
        {
          "n": "励志",
          "v": "励志"
        },
        {
          "n": "其他",
          "v": "其他"
        }
      ]
    },
    {
      "key": "area",
      "name": "地区",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "国产",
          "v": "国产"
        },
        {
          "n": "日本",
          "v": "日本"
        },
        {
          "n": "欧美",
          "v": "欧美"
        },
        {
          "n": "其他",
          "v": "其他"
        }
      ]
    },
    {
      "key": "year",
      "name": "年份",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "2026",
          "v": "2026"
        },
        {
          "n": "2025",
          "v": "2025"
        },
        {
          "n": "2024",
          "v": "2024"
        },
        {
          "n": "2023",
          "v": "2023"
        },
        {
          "n": "2022",
          "v": "2022"
        },
        {
          "n": "2021",
          "v": "2021"
        },
        {
          "n": "2020",
          "v": "2020"
        },
        {
          "n": "2019",
          "v": "2019"
        },
        {
          "n": "2018",
          "v": "2018"
        },
        {
          "n": "2017",
          "v": "2017"
        },
        {
          "n": "2016",
          "v": "2016"
        },
        {
          "n": "2015",
          "v": "2015"
        },
        {
          "n": "2014",
          "v": "2014"
        },
        {
          "n": "2013",
          "v": "2013"
        },
        {
          "n": "2012",
          "v": "2012"
        },
        {
          "n": "2011",
          "v": "2011"
        },
        {
          "n": "2010",
          "v": "2010"
        },
        {
          "n": "2009",
          "v": "2009"
        },
        {
          "n": "2008",
          "v": "2008"
        },
        {
          "n": "2007",
          "v": "2007"
        },
        {
          "n": "2006",
          "v": "2006"
        }
      ]
    },
    {
      "key": "by",
      "name": "排序",
      "init": "time",
      "value": [
        {
          "n": "时间",
          "v": "time"
        },
        {
          "n": "人气",
          "v": "hits"
        },
        {
          "n": "评分",
          "v": "score"
        }
      ]
    }
  ],
  "4": [
    {
      "key": "class",
      "name": "剧情",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "选秀",
          "v": "选秀"
        },
        {
          "n": "情感",
          "v": "情感"
        },
        {
          "n": "访谈",
          "v": "访谈"
        },
        {
          "n": "播报",
          "v": "播报"
        },
        {
          "n": "旅游",
          "v": "旅游"
        },
        {
          "n": "音乐",
          "v": "音乐"
        },
        {
          "n": "美食",
          "v": "美食"
        },
        {
          "n": "纪实",
          "v": "纪实"
        },
        {
          "n": "曲艺",
          "v": "曲艺"
        },
        {
          "n": "生活",
          "v": "生活"
        },
        {
          "n": "游戏互动",
          "v": "游戏互动"
        },
        {
          "n": "财经",
          "v": "财经"
        },
        {
          "n": "求职",
          "v": "求职"
        }
      ]
    },
    {
      "key": "area",
      "name": "地区",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "内地",
          "v": "内地"
        },
        {
          "n": "港台",
          "v": "港台"
        },
        {
          "n": "日韩",
          "v": "日韩"
        },
        {
          "n": "欧美",
          "v": "欧美"
        }
      ]
    },
    {
      "key": "year",
      "name": "年份",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "2026",
          "v": "2026"
        },
        {
          "n": "2025",
          "v": "2025"
        },
        {
          "n": "2024",
          "v": "2024"
        },
        {
          "n": "2023",
          "v": "2023"
        },
        {
          "n": "2022",
          "v": "2022"
        },
        {
          "n": "2021",
          "v": "2021"
        },
        {
          "n": "2020",
          "v": "2020"
        },
        {
          "n": "2019",
          "v": "2019"
        },
        {
          "n": "2018",
          "v": "2018"
        },
        {
          "n": "2017",
          "v": "2017"
        },
        {
          "n": "2016",
          "v": "2016"
        },
        {
          "n": "2015",
          "v": "2015"
        },
        {
          "n": "2014",
          "v": "2014"
        },
        {
          "n": "2013",
          "v": "2013"
        },
        {
          "n": "2012",
          "v": "2012"
        },
        {
          "n": "2011",
          "v": "2011"
        },
        {
          "n": "2010",
          "v": "2010"
        },
        {
          "n": "2009",
          "v": "2009"
        },
        {
          "n": "2008",
          "v": "2008"
        },
        {
          "n": "2007",
          "v": "2007"
        },
        {
          "n": "2006",
          "v": "2006"
        }
      ]
    },
    {
      "key": "by",
      "name": "排序",
      "init": "time",
      "value": [
        {
          "n": "时间",
          "v": "time"
        },
        {
          "n": "人气",
          "v": "hits"
        },
        {
          "n": "评分",
          "v": "score"
        }
      ]
    }
  ],
  "5": [
    {
      "key": "by",
      "name": "排序",
      "init": "time",
      "value": [
        {
          "n": "时间",
          "v": "time"
        },
        {
          "n": "人气",
          "v": "hits"
        },
        {
          "n": "评分",
          "v": "score"
        }
      ]
    }
  ],
  "6": [
    {
      "key": "year",
      "name": "年份",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "2026",
          "v": "2026"
        },
        {
          "n": "2025",
          "v": "2025"
        },
        {
          "n": "2024",
          "v": "2024"
        },
        {
          "n": "2023",
          "v": "2023"
        },
        {
          "n": "2022",
          "v": "2022"
        },
        {
          "n": "2021",
          "v": "2021"
        },
        {
          "n": "2020",
          "v": "2020"
        },
        {
          "n": "2019",
          "v": "2019"
        },
        {
          "n": "2018",
          "v": "2018"
        },
        {
          "n": "2017",
          "v": "2017"
        },
        {
          "n": "2016",
          "v": "2016"
        },
        {
          "n": "2015",
          "v": "2015"
        },
        {
          "n": "2014",
          "v": "2014"
        },
        {
          "n": "2013",
          "v": "2013"
        },
        {
          "n": "2012",
          "v": "2012"
        },
        {
          "n": "2011",
          "v": "2011"
        },
        {
          "n": "2010",
          "v": "2010"
        },
        {
          "n": "2009",
          "v": "2009"
        },
        {
          "n": "2008",
          "v": "2008"
        },
        {
          "n": "2007",
          "v": "2007"
        },
        {
          "n": "2006",
          "v": "2006"
        }
      ]
    },
    {
      "key": "by",
      "name": "排序",
      "init": "time",
      "value": [
        {
          "n": "时间",
          "v": "time"
        },
        {
          "n": "人气",
          "v": "hits"
        },
        {
          "n": "评分",
          "v": "score"
        }
      ]
    }
  ],
  "44": [
    {
      "key": "class",
      "name": "剧情",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "喜剧",
          "v": "喜剧"
        },
        {
          "n": "爱情",
          "v": "爱情"
        },
        {
          "n": "恐怖",
          "v": "恐怖"
        },
        {
          "n": "动作",
          "v": "动作"
        },
        {
          "n": "科幻",
          "v": "科幻"
        },
        {
          "n": "剧情",
          "v": "剧情"
        },
        {
          "n": "战争",
          "v": "战争"
        },
        {
          "n": "警匪",
          "v": "警匪"
        },
        {
          "n": "犯罪",
          "v": "犯罪"
        },
        {
          "n": "动画",
          "v": "动画"
        },
        {
          "n": "奇幻",
          "v": "奇幻"
        },
        {
          "n": "武侠",
          "v": "武侠"
        },
        {
          "n": "冒险",
          "v": "冒险"
        },
        {
          "n": "枪战",
          "v": "枪战"
        },
        {
          "n": "悬疑",
          "v": "悬疑"
        },
        {
          "n": "惊悚",
          "v": "惊悚"
        },
        {
          "n": "经典",
          "v": "经典"
        },
        {
          "n": "青春",
          "v": "青春"
        },
        {
          "n": "文艺",
          "v": "文艺"
        },
        {
          "n": "微电影",
          "v": "微电影"
        },
        {
          "n": "古装",
          "v": "古装"
        },
        {
          "n": "历史",
          "v": "历史"
        },
        {
          "n": "运动",
          "v": "运动"
        },
        {
          "n": "农村",
          "v": "农村"
        },
        {
          "n": "儿童",
          "v": "儿童"
        },
        {
          "n": "网络电影",
          "v": "网络电影"
        }
      ]
    },
    {
      "key": "area",
      "name": "地区",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "国产",
          "v": "国产"
        },
        {
          "n": "日本",
          "v": "日本"
        },
        {
          "n": "欧美",
          "v": "欧美"
        },
        {
          "n": "其他",
          "v": "其他"
        }
      ]
    },
    {
      "key": "year",
      "name": "年份",
      "init": "",
      "value": [
        {
          "n": "全部",
          "v": ""
        },
        {
          "n": "2026",
          "v": "2026"
        },
        {
          "n": "2025",
          "v": "2025"
        },
        {
          "n": "2024",
          "v": "2024"
        },
        {
          "n": "2023",
          "v": "2023"
        },
        {
          "n": "2022",
          "v": "2022"
        },
        {
          "n": "2021",
          "v": "2021"
        },
        {
          "n": "2020",
          "v": "2020"
        },
        {
          "n": "2019",
          "v": "2019"
        },
        {
          "n": "2018",
          "v": "2018"
        },
        {
          "n": "2017",
          "v": "2017"
        },
        {
          "n": "2016",
          "v": "2016"
        },
        {
          "n": "2015",
          "v": "2015"
        },
        {
          "n": "2014",
          "v": "2014"
        },
        {
          "n": "2013",
          "v": "2013"
        },
        {
          "n": "2012",
          "v": "2012"
        },
        {
          "n": "2011",
          "v": "2011"
        },
        {
          "n": "2010",
          "v": "2010"
        }
      ]
    },
    {
      "key": "by",
      "name": "排序",
      "init": "time",
      "value": [
        {
          "n": "时间",
          "v": "time"
        },
        {
          "n": "人气",
          "v": "hits"
        },
        {
          "n": "评分",
          "v": "score"
        }
      ]
    }
  ],
  "46": [
    {
      "key": "by",
      "name": "排序",
      "init": "time",
      "value": [
        {
          "n": "时间",
          "v": "time"
        },
        {
          "n": "人气",
          "v": "hits"
        },
        {
          "n": "评分",
          "v": "score"
        }
      ]
    }
  ]
};

const PAN_PATTERNS = [
    ['baidu', '百度', /pan\.baidu\.com|yun\.baidu\.com/i],
    ['mobile', '移动', /yun\.139\.com|mcloud\.139\.com|139\.com/i],
    ['tianyi', '天翼', /cloud\.189\.cn|189\.cn|21cn\.com/i],
    ['123', '123', /123684\.com|123865\.com|123912\.com|123592\.com|123pan\.com|123pan\.cn/i],
    ['115', '115', /115\.com|115cdn\.com|anxia\.com/i],
    ['quark', '夸克', /pan\.quark\.cn/i],
    ['xunlei', '迅雷', /pan\.xunlei\.com/i],
    ['aliyun', '阿里', /aliyundrive\.com|alipan\.com|pan\.aliyun\.com/i],
    ['uc', 'UC', /drive\.uc\.cn/i],
];
const PAN_PRIORITY = {baidu: 1, mobile: 2, tianyi: 3, '123': 4, '115': 5, quark: 6, xunlei: 7, aliyun: 8, uc: 9};
const PAN_NAMES = {};
for (const item of PAN_PATTERNS) PAN_NAMES[item[0]] = item[1];

const HOSTS_TTL = 30 * 60 * 1000;
let hosts = ['https://woggpan.xxooo.cf', 'https://wogg.xxooo.cf', 'https://woggpan.888484.xyz', 'https://www.wogg.net'];
let hostsRankedAt = 0;
// 后端(alist-tvbox)网盘解析配置,来自站点 ext 的 api/token
let panApi = '';
let panToken = '';
let siteKey = '';
let siteType = 0;

function detectPanType(url) {
    for (const item of PAN_PATTERNS) {
        if (item[2].test(url)) return [item[0], item[1]];
    }
    return ['', ''];
}

function cleanText(text) {
    return String(text || '').replace(/\xa0/g, ' ').replace(/\s+/g, ' ').trim();
}

function fixImgUrl(img) {
    const raw = String(img || '').trim();
    if (!raw) return '';
    if (raw.startsWith('/db.php?url=')) return hosts[0] + raw;
    return raw;
}

async function getRaw(url, referer) {
    const res = await req(url, {
        method: 'get',
        headers: {'User-Agent': UA, Referer: (referer || hosts[0]) + '/'},
    });
    return res;
}

async function requestHtml(path) {
    const relative = path.replace(/^https?:\/\/[^/]+/, '');
    for (let index = 0; index < hosts.length; index++) {
        const host = hosts[index];
        try {
            const res = await getRaw(host + relative, host);
            if (res.status === 200 && res.content) {
                if (index > 0) {
                    hosts.unshift(hosts.splice(index, 1)[0]);
                    hostsRankedAt = Date.now();
                }
                return res.content;
            }
        } catch (e) { /* 换下一个域名 */ }
    }
    hostsRankedAt = 0;
    throw new Error('all wogg hosts unreachable');
}

function parseCards(html) {
    const $ = load(html);
    const items = [];
    const seen = new Set();
    $('#main .module-item').each((_, node) => {
        const el = $(node);
        const href = (el.find('.module-item-pic a[href]').attr('href') || '').trim();
        const matched = href.match(/\/voddetail\/(\d+)\.html/);
        const title = (el.find('.module-item-pic img[alt]').attr('alt') || '').trim();
        if (!matched || !title || seen.has(matched[1])) return;
        seen.add(matched[1]);
        const pic = (el.find('.module-item-pic img[data-src]').attr('data-src')
            || el.find('.module-item-pic img[src]').attr('src') || '').trim();
        items.push({
            vod_id: matched[1],
            vod_name: title,
            vod_pic: fixImgUrl(pic),
            vod_remarks: cleanText(el.find('.module-item-text').first().text()),
        });
    });
    return items;
}

function pageResult(items, pg) {
    const page = parseInt(pg, 10) || 1;
    return JSON.stringify({page: page, pagecount: items.length ? page + 1 : page, limit: items.length, total: page * 20 + items.length, list: items});
}

async function init(cfg) {
    siteKey = cfg.skey;
    siteType = cfg.stype;
    const site = String(cfg.ext && cfg.ext.site || cfg.ext && cfg.ext.url || (typeof cfg.ext === 'string' && cfg.ext.startsWith('http') ? cfg.ext : '') || '').trim();
    if (/^https?:\/\//i.test(site)) {
        hosts = [site.replace(/\/$/, '')];
        hostsRankedAt = 0;
    } else if (site) {
        hosts = ['https://' + site.replace(/\/$/, '')];
        hostsRankedAt = 0;
    }
    panApi = String(ext.api || '').replace(/\/$/, '');
    panToken = String(ext.token || '');
    return '{}';
}

// 网盘分享链接→后端 /parse 转文件夹集列表;失败回退单集透传
async function parsePanUrl(shareUrl, title) {
    if (!panApi) return null;
    try {
        const res = await req(`${panApi}/parse/${panToken}?ac=play`, {
            method: 'post',
            data: JSON.stringify({url: shareUrl, title: title || ''}),
            headers: {'User-Agent': UA, 'Content-Type': 'application/json'},
        });
        const parsed = JSON.parse(res.content || '{}');
        const first = parsed && parsed.list && parsed.list[0];
        if (first && first.vod_play_url) return first.vod_play_url;
    } catch (e) { /* 回退 */ }
    return null;
}

async function home(filter) {
    return JSON.stringify({class: CATEGORIES, filters: FILTERS});
}

async function homeVod() {
    return '{}';
}

async function category(tid, pg, filter, extend) {
    if (pg <= 0) pg = 1;
    extend = extend || {};
    const area = encodeURIComponent(extend.area || '');
    const by = encodeURIComponent(extend.by || extend.sort || '');
    const klass = encodeURIComponent(extend.class || '');
    const year = encodeURIComponent(extend.year || '');
    let path;
    if (area || by || klass || year) {
        path = `/vodshow/${tid}-${area}-${by}-${klass}-----${pg}---${year}.html`;
    } else {
        path = `/vodshow/${tid}--------${pg}---.html`;
    }
    return pageResult(parseCards(await requestHtml(path)), pg);
}

async function detail(id) {
    const html = await requestHtml(`/voddetail/${id}.html`);
    const $ = load(html);
    const info = {vod_year: '', vod_director: '', vod_actor: '', vod_content: ''};
    $('.video-info-itemtitle').each((_, node) => {
        const key = cleanText($(node).text());
        const sibling = $(node).next();
        if (!sibling.length) return;
        const joined = sibling.find('a').map((_, a) => cleanText($(a).text())).get().filter(Boolean).join(',');
        const textValue = cleanText(sibling.text());
        const value = joined || textValue;
        if (key.includes('年代')) info.vod_year = value;
        else if (key.includes('导演')) info.vod_director = value;
        else if (key.includes('主演')) info.vod_actor = value;
        else if (key.includes('剧情')) info.vod_content = textValue;
    });
    const panUrls = [];
    $('.module-row-info p').each((_, node) => {
        const text = cleanText($(node).text());
        if (text) panUrls.push(text);
    });
    const lines = [];
    const seen = new Set();
    for (const url of panUrls) {
        const type = detectPanType(url)[0];
        if (!type || seen.has(url)) continue;
        seen.add(url);
        lines.push({priority: PAN_PRIORITY[type] || 999, from: `${PAN_NAMES[type]}#玩偶哥哥`, url: `${PAN_NAMES[type]}$${url}`});
    }
    lines.sort((a, b) => a.priority - b.priority);
    const title = cleanText($('.page-title').first().text());
    // 网盘线路转文件夹:后端解析失败回退单集透传
    const urlParts = await Promise.all(lines.map(async line => {
        const shareUrl = line.url.split('$').slice(1).join('$');
        return await parsePanUrl(shareUrl, title) || line.url;
    }));
    return JSON.stringify({
        list: [{
            vod_id: id,
            vod_name: title,
            vod_pic: fixImgUrl($('.mobile-play .lazyload').attr('data-src') || $('.mobile-play .lazyload').attr('src') || ''),
            vod_year: info.vod_year,
            vod_director: info.vod_director,
            vod_actor: info.vod_actor,
            vod_content: info.vod_content,
            vod_play_from: lines.map(l => l.from).join('$$$'),
            vod_play_url: urlParts.join('$$$'),
        }],
    });
}

async function play(flag, id, flags) {
    // 1@pid 形态(后端文件夹条目)→透传后端 /play 取直链
    if (panApi && id.includes('@') && !id.startsWith('http')) {
        try {
            const res = await req(`${panApi}/play/${panToken}?id=${encodeURIComponent(id)}`, {method: 'get', headers: {'User-Agent': UA}});
            return res.content || JSON.stringify({parse: 0, url: ''});
        } catch (e) { /* 回退 */ }
    }
    const type = detectPanType(id)[0];
    if (type) {
        return JSON.stringify({parse: 0, playUrl: '', url: id});
    }
    return JSON.stringify({parse: 0, playUrl: '', url: ''});
}

async function search(wd, quick, pg) {
    if (pg <= 0) pg = 1;
    wd = cleanText(wd);
    if (!wd) return JSON.stringify({page: pg, pagecount: pg, total: 0, list: []});
    const html = await requestHtml(`/vodsearch/-------------.html?wd=${encodeURIComponent(wd)}&page=${pg}`);
    const $ = load(html);
    const items = [];
    $('.module-search-item').each((_, node) => {
        const el = $(node);
        const serial = el.find('.video-serial').first();
        const href = (serial.attr('href') || '').trim();
        const matched = href.match(/\/voddetail\/(\d+)\.html/);
        const title = (serial.attr('title') || '').trim();
        if (!matched || !title) return;
        const pic = (el.find('.module-item-pic img[data-src]').attr('data-src')
            || el.find('.module-item-pic img[src]').attr('src') || '').trim();
        items.push({
            vod_id: matched[1],
            vod_name: title,
            vod_pic: fixImgUrl(pic),
            vod_remarks: cleanText(serial.text()) || cleanText(el.find('.module-item-text').first().text()),
        });
    });
    return JSON.stringify({page: pg, pagecount: items.length ? pg + 1 : pg, total: items.length, list: items});
}

function __jsEvalReturn() {
    return {
        init: init,
        home: home,
        homeVod: homeVod,
        category: category,
        detail: detail,
        play: play,
        search: search,
    };
}
