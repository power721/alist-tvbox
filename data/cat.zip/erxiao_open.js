// 二小[盘] OpenCat 版——由 gen-pansou-spiders.py 生成,与 node 版同源逻辑。
import { load } from 'assets://js/lib/cat.js';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36';

const CATEGORIES = [
    {
        "type_id": "1",
        "type_name": "二小电影"
    },
    {
        "type_id": "2",
        "type_name": "二小剧集"
    },
    {
        "type_id": "3",
        "type_name": "二小动漫"
    },
    {
        "type_id": "17",
        "type_name": "二小综艺"
    }
];

const FILTERS = {
    "1": [
        {
            "key": "class",
            "name": "剧情",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "喜剧",
                    "v": "喜剧"
                },
                {
                    "n": "爱情",
                    "v": "爱情"
                },
                {
                    "n": "恐怖",
                    "v": "恐怖"
                },
                {
                    "n": "动作",
                    "v": "动作"
                },
                {
                    "n": "科幻",
                    "v": "科幻"
                },
                {
                    "n": "剧情",
                    "v": "剧情"
                },
                {
                    "n": "战争",
                    "v": "战争"
                },
                {
                    "n": "警匪",
                    "v": "警匪"
                },
                {
                    "n": "犯罪",
                    "v": "犯罪"
                },
                {
                    "n": "动画",
                    "v": "动画"
                },
                {
                    "n": "奇幻",
                    "v": "奇幻"
                },
                {
                    "n": "武侠",
                    "v": "武侠"
                },
                {
                    "n": "冒险",
                    "v": "冒险"
                },
                {
                    "n": "枪战",
                    "v": "枪战"
                },
                {
                    "n": "悬疑",
                    "v": "悬疑"
                },
                {
                    "n": "惊悚",
                    "v": "惊悚"
                },
                {
                    "n": "经典",
                    "v": "经典"
                },
                {
                    "n": "青春",
                    "v": "青春"
                },
                {
                    "n": "文艺",
                    "v": "文艺"
                },
                {
                    "n": "微电影",
                    "v": "微电影"
                },
                {
                    "n": "古装",
                    "v": "古装"
                },
                {
                    "n": "历史",
                    "v": "历史"
                },
                {
                    "n": "运动",
                    "v": "运动"
                },
                {
                    "n": "农村",
                    "v": "农村"
                },
                {
                    "n": "儿童",
                    "v": "儿童"
                },
                {
                    "n": "网络电影",
                    "v": "网络电影"
                }
            ]
        },
        {
            "key": "area",
            "name": "地区",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "大陆",
                    "v": "大陆"
                },
                {
                    "n": "香港",
                    "v": "香港"
                },
                {
                    "n": "台湾",
                    "v": "台湾"
                },
                {
                    "n": "美国",
                    "v": "美国"
                },
                {
                    "n": "法国",
                    "v": "法国"
                },
                {
                    "n": "英国",
                    "v": "英国"
                },
                {
                    "n": "日本",
                    "v": "日本"
                },
                {
                    "n": "韩国",
                    "v": "韩国"
                },
                {
                    "n": "德国",
                    "v": "德国"
                },
                {
                    "n": "泰国",
                    "v": "泰国"
                },
                {
                    "n": "印度",
                    "v": "印度"
                },
                {
                    "n": "意大利",
                    "v": "意大利"
                },
                {
                    "n": "西班牙",
                    "v": "西班牙"
                },
                {
                    "n": "加拿大",
                    "v": "加拿大"
                },
                {
                    "n": "其他",
                    "v": "其他"
                }
            ]
        },
        {
            "key": "lang",
            "name": "语言",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "国语",
                    "v": "国语"
                },
                {
                    "n": "英语",
                    "v": "英语"
                },
                {
                    "n": "粤语",
                    "v": "粤语"
                },
                {
                    "n": "闽南语",
                    "v": "闽南语"
                },
                {
                    "n": "韩语",
                    "v": "韩语"
                },
                {
                    "n": "日语",
                    "v": "日语"
                },
                {
                    "n": "法语",
                    "v": "法语"
                },
                {
                    "n": "德语",
                    "v": "德语"
                },
                {
                    "n": "其它",
                    "v": "其它"
                }
            ]
        },
        {
            "key": "year",
            "name": "年份",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "2026",
                    "v": "2026"
                },
                {
                    "n": "2025",
                    "v": "2025"
                },
                {
                    "n": "2024",
                    "v": "2024"
                },
                {
                    "n": "2023",
                    "v": "2023"
                },
                {
                    "n": "2022",
                    "v": "2022"
                },
                {
                    "n": "2021",
                    "v": "2021"
                },
                {
                    "n": "2020",
                    "v": "2020"
                },
                {
                    "n": "2019",
                    "v": "2019"
                },
                {
                    "n": "2018",
                    "v": "2018"
                },
                {
                    "n": "2017",
                    "v": "2017"
                },
                {
                    "n": "2016",
                    "v": "2016"
                },
                {
                    "n": "2015",
                    "v": "2015"
                },
                {
                    "n": "2014",
                    "v": "2014"
                },
                {
                    "n": "2013",
                    "v": "2013"
                },
                {
                    "n": "2012",
                    "v": "2012"
                },
                {
                    "n": "2011",
                    "v": "2011"
                },
                {
                    "n": "2010",
                    "v": "2010"
                }
            ]
        },
        {
            "key": "letter",
            "name": "字母",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "A",
                    "v": "A"
                },
                {
                    "n": "B",
                    "v": "B"
                },
                {
                    "n": "C",
                    "v": "C"
                },
                {
                    "n": "D",
                    "v": "D"
                },
                {
                    "n": "E",
                    "v": "E"
                },
                {
                    "n": "F",
                    "v": "F"
                },
                {
                    "n": "G",
                    "v": "G"
                },
                {
                    "n": "H",
                    "v": "H"
                },
                {
                    "n": "I",
                    "v": "I"
                },
                {
                    "n": "J",
                    "v": "J"
                },
                {
                    "n": "K",
                    "v": "K"
                },
                {
                    "n": "L",
                    "v": "L"
                },
                {
                    "n": "M",
                    "v": "M"
                },
                {
                    "n": "N",
                    "v": "N"
                },
                {
                    "n": "O",
                    "v": "O"
                },
                {
                    "n": "P",
                    "v": "P"
                },
                {
                    "n": "Q",
                    "v": "Q"
                },
                {
                    "n": "R",
                    "v": "R"
                },
                {
                    "n": "S",
                    "v": "S"
                },
                {
                    "n": "T",
                    "v": "T"
                },
                {
                    "n": "U",
                    "v": "U"
                },
                {
                    "n": "V",
                    "v": "V"
                },
                {
                    "n": "W",
                    "v": "W"
                },
                {
                    "n": "X",
                    "v": "X"
                },
                {
                    "n": "Y",
                    "v": "Y"
                },
                {
                    "n": "Z",
                    "v": "Z"
                },
                {
                    "n": "0-9",
                    "v": "0-9"
                }
            ]
        },
        {
            "key": "by",
            "name": "排序",
            "init": "time",
            "value": [
                {
                    "n": "时间",
                    "v": "time"
                },
                {
                    "n": "人气",
                    "v": "hits"
                },
                {
                    "n": "评分",
                    "v": "score"
                }
            ]
        }
    ],
    "2": [
        {
            "key": "class",
            "name": "剧情",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "古装",
                    "v": "古装"
                },
                {
                    "n": "战争",
                    "v": "战争"
                },
                {
                    "n": "青春偶像",
                    "v": "青春偶像"
                },
                {
                    "n": "喜剧",
                    "v": "喜剧"
                },
                {
                    "n": "家庭",
                    "v": "家庭"
                },
                {
                    "n": "犯罪",
                    "v": "犯罪"
                },
                {
                    "n": "动作",
                    "v": "动作"
                },
                {
                    "n": "奇幻",
                    "v": "奇幻"
                },
                {
                    "n": "剧情",
                    "v": "剧情"
                },
                {
                    "n": "历史",
                    "v": "历史"
                },
                {
                    "n": "经典",
                    "v": "经典"
                },
                {
                    "n": "乡村",
                    "v": "乡村"
                },
                {
                    "n": "情景",
                    "v": "情景"
                },
                {
                    "n": "商战",
                    "v": "商战"
                },
                {
                    "n": "网剧",
                    "v": "网剧"
                },
                {
                    "n": "其他",
                    "v": "其他"
                }
            ]
        },
        {
            "key": "area",
            "name": "地区",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "内地",
                    "v": "内地"
                },
                {
                    "n": "韩国",
                    "v": "韩国"
                },
                {
                    "n": "香港",
                    "v": "香港"
                },
                {
                    "n": "台湾",
                    "v": "台湾"
                },
                {
                    "n": "日本",
                    "v": "日本"
                },
                {
                    "n": "美国",
                    "v": "美国"
                },
                {
                    "n": "泰国",
                    "v": "泰国"
                },
                {
                    "n": "英国",
                    "v": "英国"
                },
                {
                    "n": "新加坡",
                    "v": "新加坡"
                },
                {
                    "n": "其他",
                    "v": "其他"
                }
            ]
        },
        {
            "key": "lang",
            "name": "语言",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "国语",
                    "v": "国语"
                },
                {
                    "n": "英语",
                    "v": "英语"
                },
                {
                    "n": "粤语",
                    "v": "粤语"
                },
                {
                    "n": "闽南语",
                    "v": "闽南语"
                },
                {
                    "n": "韩语",
                    "v": "韩语"
                },
                {
                    "n": "日语",
                    "v": "日语"
                },
                {
                    "n": "其它",
                    "v": "其它"
                }
            ]
        },
        {
            "key": "year",
            "name": "年份",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "2026",
                    "v": "2026"
                },
                {
                    "n": "2025",
                    "v": "2025"
                },
                {
                    "n": "2024",
                    "v": "2024"
                },
                {
                    "n": "2023",
                    "v": "2023"
                },
                {
                    "n": "2022",
                    "v": "2022"
                },
                {
                    "n": "2021",
                    "v": "2021"
                },
                {
                    "n": "2020",
                    "v": "2020"
                },
                {
                    "n": "2019",
                    "v": "2019"
                },
                {
                    "n": "2018",
                    "v": "2018"
                },
                {
                    "n": "2017",
                    "v": "2017"
                },
                {
                    "n": "2016",
                    "v": "2016"
                },
                {
                    "n": "2015",
                    "v": "2015"
                },
                {
                    "n": "2014",
                    "v": "2014"
                },
                {
                    "n": "2013",
                    "v": "2013"
                },
                {
                    "n": "2012",
                    "v": "2012"
                },
                {
                    "n": "2011",
                    "v": "2011"
                },
                {
                    "n": "2010",
                    "v": "2010"
                }
            ]
        },
        {
            "key": "letter",
            "name": "字母",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "A",
                    "v": "A"
                },
                {
                    "n": "B",
                    "v": "B"
                },
                {
                    "n": "C",
                    "v": "C"
                },
                {
                    "n": "D",
                    "v": "D"
                },
                {
                    "n": "E",
                    "v": "E"
                },
                {
                    "n": "F",
                    "v": "F"
                },
                {
                    "n": "G",
                    "v": "G"
                },
                {
                    "n": "H",
                    "v": "H"
                },
                {
                    "n": "I",
                    "v": "I"
                },
                {
                    "n": "J",
                    "v": "J"
                },
                {
                    "n": "K",
                    "v": "K"
                },
                {
                    "n": "L",
                    "v": "L"
                },
                {
                    "n": "M",
                    "v": "M"
                },
                {
                    "n": "N",
                    "v": "N"
                },
                {
                    "n": "O",
                    "v": "O"
                },
                {
                    "n": "P",
                    "v": "P"
                },
                {
                    "n": "Q",
                    "v": "Q"
                },
                {
                    "n": "R",
                    "v": "R"
                },
                {
                    "n": "S",
                    "v": "S"
                },
                {
                    "n": "T",
                    "v": "T"
                },
                {
                    "n": "U",
                    "v": "U"
                },
                {
                    "n": "V",
                    "v": "V"
                },
                {
                    "n": "W",
                    "v": "W"
                },
                {
                    "n": "X",
                    "v": "X"
                },
                {
                    "n": "Y",
                    "v": "Y"
                },
                {
                    "n": "Z",
                    "v": "Z"
                },
                {
                    "n": "0-9",
                    "v": "0-9"
                }
            ]
        },
        {
            "key": "by",
            "name": "排序",
            "init": "time",
            "value": [
                {
                    "n": "时间",
                    "v": "time"
                },
                {
                    "n": "人气",
                    "v": "hits"
                },
                {
                    "n": "评分",
                    "v": "score"
                }
            ]
        }
    ],
    "3": [
        {
            "key": "area",
            "name": "地区",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "内地",
                    "v": "内地"
                },
                {
                    "n": "港台",
                    "v": "港台"
                },
                {
                    "n": "日韩",
                    "v": "日韩"
                },
                {
                    "n": "欧美",
                    "v": "欧美"
                }
            ]
        },
        {
            "key": "lang",
            "name": "语言",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "国语",
                    "v": "国语"
                },
                {
                    "n": "英语",
                    "v": "英语"
                },
                {
                    "n": "粤语",
                    "v": "粤语"
                },
                {
                    "n": "闽南语",
                    "v": "闽南语"
                },
                {
                    "n": "韩语",
                    "v": "韩语"
                },
                {
                    "n": "日语",
                    "v": "日语"
                },
                {
                    "n": "其它",
                    "v": "其它"
                }
            ]
        },
        {
            "key": "year",
            "name": "年份",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "2026",
                    "v": "2026"
                },
                {
                    "n": "2025",
                    "v": "2025"
                },
                {
                    "n": "2024",
                    "v": "2024"
                },
                {
                    "n": "2023",
                    "v": "2023"
                },
                {
                    "n": "2022",
                    "v": "2022"
                },
                {
                    "n": "2021",
                    "v": "2021"
                },
                {
                    "n": "2020",
                    "v": "2020"
                },
                {
                    "n": "2019",
                    "v": "2019"
                },
                {
                    "n": "2018",
                    "v": "2018"
                },
                {
                    "n": "2017",
                    "v": "2017"
                },
                {
                    "n": "2016",
                    "v": "2016"
                },
                {
                    "n": "2015",
                    "v": "2015"
                },
                {
                    "n": "2014",
                    "v": "2014"
                },
                {
                    "n": "2013",
                    "v": "2013"
                },
                {
                    "n": "2012",
                    "v": "2012"
                },
                {
                    "n": "2011",
                    "v": "2011"
                },
                {
                    "n": "2010",
                    "v": "2010"
                }
            ]
        },
        {
            "key": "letter",
            "name": "字母",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "A",
                    "v": "A"
                },
                {
                    "n": "B",
                    "v": "B"
                },
                {
                    "n": "C",
                    "v": "C"
                },
                {
                    "n": "D",
                    "v": "D"
                },
                {
                    "n": "E",
                    "v": "E"
                },
                {
                    "n": "F",
                    "v": "F"
                },
                {
                    "n": "G",
                    "v": "G"
                },
                {
                    "n": "H",
                    "v": "H"
                },
                {
                    "n": "I",
                    "v": "I"
                },
                {
                    "n": "J",
                    "v": "J"
                },
                {
                    "n": "K",
                    "v": "K"
                },
                {
                    "n": "L",
                    "v": "L"
                },
                {
                    "n": "M",
                    "v": "M"
                },
                {
                    "n": "N",
                    "v": "N"
                },
                {
                    "n": "O",
                    "v": "O"
                },
                {
                    "n": "P",
                    "v": "P"
                },
                {
                    "n": "Q",
                    "v": "Q"
                },
                {
                    "n": "R",
                    "v": "R"
                },
                {
                    "n": "S",
                    "v": "S"
                },
                {
                    "n": "T",
                    "v": "T"
                },
                {
                    "n": "U",
                    "v": "U"
                },
                {
                    "n": "V",
                    "v": "V"
                },
                {
                    "n": "W",
                    "v": "W"
                },
                {
                    "n": "X",
                    "v": "X"
                },
                {
                    "n": "Y",
                    "v": "Y"
                },
                {
                    "n": "Z",
                    "v": "Z"
                },
                {
                    "n": "0-9",
                    "v": "0-9"
                }
            ]
        },
        {
            "key": "by",
            "name": "排序",
            "init": "time",
            "value": [
                {
                    "n": "时间",
                    "v": "time"
                },
                {
                    "n": "人气",
                    "v": "hits"
                },
                {
                    "n": "评分",
                    "v": "score"
                }
            ]
        }
    ],
    "17": [
        {
            "key": "letter",
            "name": "字母",
            "init": "",
            "value": [
                {
                    "n": "全部",
                    "v": ""
                },
                {
                    "n": "A",
                    "v": "A"
                },
                {
                    "n": "B",
                    "v": "B"
                },
                {
                    "n": "C",
                    "v": "C"
                },
                {
                    "n": "D",
                    "v": "D"
                },
                {
                    "n": "E",
                    "v": "E"
                },
                {
                    "n": "F",
                    "v": "F"
                },
                {
                    "n": "G",
                    "v": "G"
                },
                {
                    "n": "H",
                    "v": "H"
                },
                {
                    "n": "I",
                    "v": "I"
                },
                {
                    "n": "J",
                    "v": "J"
                },
                {
                    "n": "K",
                    "v": "K"
                },
                {
                    "n": "L",
                    "v": "L"
                },
                {
                    "n": "M",
                    "v": "M"
                },
                {
                    "n": "N",
                    "v": "N"
                },
                {
                    "n": "O",
                    "v": "O"
                },
                {
                    "n": "P",
                    "v": "P"
                },
                {
                    "n": "Q",
                    "v": "Q"
                },
                {
                    "n": "R",
                    "v": "R"
                },
                {
                    "n": "S",
                    "v": "S"
                },
                {
                    "n": "T",
                    "v": "T"
                },
                {
                    "n": "U",
                    "v": "U"
                },
                {
                    "n": "V",
                    "v": "V"
                },
                {
                    "n": "W",
                    "v": "W"
                },
                {
                    "n": "X",
                    "v": "X"
                },
                {
                    "n": "Y",
                    "v": "Y"
                },
                {
                    "n": "Z",
                    "v": "Z"
                },
                {
                    "n": "0-9",
                    "v": "0-9"
                }
            ]
        },
        {
            "key": "by",
            "name": "排序",
            "init": "time",
            "value": [
                {
                    "n": "时间",
                    "v": "time"
                },
                {
                    "n": "人气",
                    "v": "hits"
                },
                {
                    "n": "评分",
                    "v": "score"
                }
            ]
        }
    ]
};

const PAN_PATTERNS = [
    ["baidu", "百度", /pan\.baidu\.com|yun\.baidu\.com/i],
    ["mobile", "移动", /yun\.139\.com|mcloud\.139\.com|139\.com/i],
    ["tianyi", "天翼", /cloud\.189\.cn|189\.cn|21cn\.com/i],
    ["123", "123", /123684\.com|123865\.com|123912\.com|123592\.com|123pan\.com|123pan\.cn/i],
    ["115", "115", /115\.com|115cdn\.com|anxia\.com/i],
    ["quark", "夸克", /pan\.quark\.cn/i],
    ["xunlei", "迅雷", /pan\.xunlei\.com/i],
    ["aliyun", "阿里", /aliyundrive\.com|alipan\.com|pan\.aliyun\.com/i],
    ["uc", "UC", /drive\.uc\.cn/i]
];
const PAN_PRIORITY = {};
const PAN_NAMES = {};
for (const item of PAN_PATTERNS) PAN_NAMES[item[0]] = item[1];

const HOSTS_TTL = 30 * 60 * 1000;
let hosts = ["https://www.2xiaopan.top", "https://wexwp.cc", "https://www.wexwp.cc"];
let hostsRankedAt = 0;
// 后端(alist-tvbox)网盘解析配置,来自站点 ext 的 api/token
let panApi = '';
let panToken = '';

function detectPanType(url) {
    for (const item of PAN_PATTERNS) {
        if (item[2].test(url)) return item[0];
    }
    return '';
}

function cleanText(text) {
    return String(text || '').replace(/\xa0/g, ' ').replace(/\s+/g, ' ').trim();
}

function fixImgUrl(img) {
    const raw = String(img || '').trim();
    if (!raw) return '';
    if (raw.startsWith('/db.php?url=')) return hosts[0] + raw;
    return raw;
}

async function requestHtml(path) {
    for (let index = 0; index < hosts.length; index++) {
        const host = hosts[index];
        try {
            const res = await req(host + path, {method: 'get', headers: {'User-Agent': UA, Referer: host + '/'}});
            if (res.status === 200 && res.content) {
                if (index > 0) {
                    hosts.unshift(hosts.splice(index, 1)[0]);
                    hostsRankedAt = Date.now();
                }
                return res.content;
            }
        } catch (e) { /* 换下一个域名 */ }
    }
    throw new Error('all erxiao hosts unreachable');
}

function buildCategoryPath(tid, pg, extend) {
    extend = extend || {};
    const hasFilter = ['class', 'area', 'lang', 'year', 'letter', 'by'].some(k => extend[k]);
    const enc = encodeURIComponent;
    if (!hasFilter) {
        return '/index.php/vod/show/id/' + enc(tid) + '/page/' + pg + '.html';
    }
    const seg = ['/index.php/vod/show'];
    if (extend.class) seg.push('/class/' + enc(extend.class));
    if (extend.area) seg.push('/area/' + enc(extend.area));
    seg.push('/id/' + enc(tid));
    if (extend.lang) seg.push('/lang/' + enc(extend.lang));
    if (extend.year) seg.push('/year/' + enc(extend.year));
    if (extend.letter) seg.push('/letter/' + enc(extend.letter));
    if (extend.by) seg.push('/by/' + enc(extend.by));
    seg.push('/page/' + pg + '.html');
    return seg.join('');
}

function parseCards(html) {
    const $ = load(html);
    const items = [];
    const seen = new Set();
    $('#main .module-item').each((_, node) => {
        const el = $(node);
        const href = (el.find('.module-item-pic a[href]').attr('href') || '').trim();
        const matched = href.match(/\/index\.php\/vod\/detail\/id\/(\d+)\.html/);
        const title = (el.find('.module-item-pic img[alt]').attr('alt') || '').trim();
        if (!matched || !title || seen.has(matched[1])) return;
        seen.add(matched[1]);
        const pic = (el.find('.module-item-pic img[data-src]').attr('data-src')
            || el.find('.module-item-pic img[src]').attr('src') || '').trim();
        items.push({
            vod_id: matched[1],
            vod_name: title,
            vod_pic: fixImgUrl(pic),
            vod_remarks: cleanText(el.find('.module-item-text').first().text()),
        });
    });
    return items;
}

function pageResult(items, pg) {
    const page = parseInt(pg, 10) || 1;
    return JSON.stringify({page: page, pagecount: items.length ? page + 1 : page, limit: items.length, total: page * 20 + items.length, list: items});
}

async function init(cfg) {
    const ext = cfg.ext || {};
    const site = String(ext.site || ext.url || (typeof cfg.ext === 'string' && cfg.ext.startsWith('http') ? cfg.ext : '') || '').trim();
    if (site) {
        hosts = [/^https?:\/\//i.test(site) ? site : 'https://' + site].map(h => h.replace(/\/$/, ''));
        hostsRankedAt = 0;
    }
    panApi = String(ext.api || '').replace(/\/$/, '');
    panToken = String(ext.token || '');
    return '{}';
}

// 网盘分享链接→后端 /parse 转文件夹集列表;失败回退单集透传
async function parsePanUrl(shareUrl, title) {
    if (!panApi) return null;
    try {
        const res = await req(`${panApi}/parse/${panToken}?ac=play`, {
            method: 'post',
            data: JSON.stringify({url: shareUrl, title: title || ''}),
            headers: {'User-Agent': UA, 'Content-Type': 'application/json'},
        });
        const parsed = JSON.parse(res.content || '{}');
        const first = parsed && parsed.list && parsed.list[0];
        if (first && first.vod_play_url) return first.vod_play_url;
    } catch (e) { /* 回退 */ }
    return null;
}

async function home(filter) {
    return JSON.stringify({class: CATEGORIES, filters: FILTERS});
}

async function homeVod() {
    return '{}';
}

async function category(tid, pg, filter, extend) {
    if (pg <= 0) pg = 1;
    return pageResult(parseCards(await requestHtml(buildCategoryPath(tid, pg, extend))), pg);
}

async function detail(id) {
    const html = await requestHtml(`/index.php/vod/detail/id/${id}.html`);
    const $ = load(html);
    const info = {vod_year: '', vod_director: '', vod_actor: '', vod_content: ''};
    $('.video-info-itemtitle').each((_, node) => {
        const key = cleanText($(node).text());
        const sibling = $(node).next();
        if (!sibling.length) return;
        const joined = sibling.find('a').map((_, a) => cleanText($(a).text())).get().filter(Boolean).join(',');
        const textValue = cleanText(sibling.text());
        const value = joined || textValue;
        if (key.includes('年代')) info.vod_year = value;
        else if (key.includes('导演')) info.vod_director = value;
        else if (key.includes('主演')) info.vod_actor = value;
        else if (key.includes('剧情')) info.vod_content = textValue;
    });
    const panUrls = [];
    $('.module-row-info p').each((_, node) => {
        const text = cleanText($(node).text());
        if (text) panUrls.push(text);
    });
    const lines = [];
    const seen = new Set();
    for (const url of panUrls) {
        const type = detectPanType(url);
        if (!type || seen.has(url)) continue;
        seen.add(url);
        lines.push({priority: PAN_PRIORITY[type] || 999, from: `${PAN_NAMES[type]}#二小`, url: `${PAN_NAMES[type]}$${url}`});
    }
    lines.sort((a, b) => a.priority - b.priority);
    const title = cleanText($('.page-title').first().text());
    // 网盘线路转文件夹:后端解析失败回退单集透传
    const urlParts = await Promise.all(lines.map(async line => {
        const shareUrl = line.url.split('$').slice(1).join('$');
        return await parsePanUrl(shareUrl, title) || line.url;
    }));
    return JSON.stringify({list: [{
        vod_id: id,
        vod_name: title,
        vod_pic: fixImgUrl($('.mobile-play .lazyload').attr('data-src') || $('.mobile-play .lazyload').attr('src') || ''),
        vod_year: info.vod_year,
        vod_director: info.vod_director,
        vod_actor: info.vod_actor,
        vod_content: info.vod_content,
        vod_play_from: lines.map(l => l.from).join('$$$'),
        vod_play_url: urlParts.join('$$$'),
    }]});
}

async function play(flag, id, flags) {
    // 1@pid 形态(后端文件夹条目)→透传后端 /play 取直链
    if (panApi && id.includes('@') && !id.startsWith('http')) {
        try {
            const res = await req(`${panApi}/play/${panToken}?id=${encodeURIComponent(id)}`, {method: 'get', headers: {'User-Agent': UA}});
            return res.content || JSON.stringify({parse: 0, url: ''});
        } catch (e) { /* 回退 */ }
    }
    if (detectPanType(id)) {
        return JSON.stringify({parse: 0, playUrl: '', url: id});
    }
    return JSON.stringify({parse: 0, playUrl: '', url: ''});
}

async function search(wd, quick, pg) {
    if (pg <= 0) pg = 1;
    wd = cleanText(wd);
    if (!wd) return JSON.stringify({page: pg, pagecount: pg, total: 0, list: []});
    const path = `/index.php/vod/search/page/${pg}/wd/${encodeURIComponent(wd)}.html`;
    const $ = load(await requestHtml(path));
    const items = [];
    $('.module-search-item').each((_, node) => {
        const el = $(node);
        const serial = el.find('.video-serial').first();
        const href = (serial.attr('href') || '').trim();
        const matched = href.match(/\/index\.php\/vod\/detail\/id\/(\d+)\.html/);
        const title = (serial.attr('title') || '').trim();
        if (!matched || !title) return;
        const pic = (el.find('.module-item-pic img[data-src]').attr('data-src')
            || el.find('.module-item-pic img[src]').attr('src') || '').trim();
        items.push({
            vod_id: matched[1],
            vod_name: title,
            vod_pic: fixImgUrl(pic),
            vod_remarks: cleanText(serial.text()) || cleanText(el.find('.module-item-text').first().text()),
        });
    });
    return JSON.stringify({page: pg, pagecount: items.length ? pg + 1 : pg, total: items.length, list: items});
}

function __jsEvalReturn() {
    return {
        init: init,
        home: home,
        homeVod: homeVod,
        category: category,
        detail: detail,
        play: play,
        search: search,
    };
}
