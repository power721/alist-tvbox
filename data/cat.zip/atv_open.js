// 本项目后端内置源的通用猫影视适配器。
// ext 约定(对象或 JSON 字符串):
//   api      L2 主端点(含 token 路径),如 http://host/media/TOKEN
//   play     播放端点(含 token 路径),缺省表示源不带播放(detail 内联地址)
//   idParam  播放请求的 id 参数名,默认 id(BiliBili 用 bvid,但 BiliBili 走专用 bilibili.js)
//   params   播放请求附加参数,如 {from: 'open', t: '0'}
//   query    所有请求附加的公共参数,如 {web: 'true'}(TG 网页源)
//   homeVod  首页推荐参数,false 表示源不支持
//   detail   false 表示源不支持详情(片单导航型,与 Java spider 缺省行为一致)
//   search   false 表示源不支持搜索
let siteKey = '';
let siteType = 0;
let ext = {};

const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1';

async function request(reqUrl) {
    const headers = { 'User-Agent': UA, 'X-CLIENT': 'open' };
    const res = await req(reqUrl, { method: 'get', headers: headers });
    return res.content;
}

function buildUrl(base, params) {
    const query = Object.entries(params)
        .filter(([, value]) => value !== undefined && value !== null)
        .map(([key, value]) => key + '=' + encodeURIComponent(value))
        .join('&');
    return query ? base + '?' + query : base;
}

async function init(cfg) {
    siteKey = cfg.skey;
    siteType = cfg.stype;
    if (typeof cfg.ext === 'string') {
        try {
            ext = JSON.parse(cfg.ext);
        } catch (e) {
            ext = { api: cfg.ext };
        }
    } else {
        ext = cfg.ext || {};
    }
    if (!ext.api) {
        throw new Error('missing ext.api');
    }
}

async function home(filter) {
    return await request(buildUrl(ext.api, ext.query || {}));
}

async function homeVod() {
    if (!ext.homeVod) {
        return '{}';
    }
    return await request(buildUrl(ext.api, Object.assign({}, ext.query, ext.homeVod)));
}

async function category(tid, pg, filter, extend) {
    if (pg <= 0) pg = 1;
    const params = Object.assign({ t: tid, pg: pg }, ext.query);
    if (extend && Object.keys(extend).length) {
        Object.assign(params, extend);
        params.f = JSON.stringify(extend);
    }
    return await request(buildUrl(ext.api, params));
}

async function detail(id) {
    if (ext.detail === false) {
        return '{}';
    }
    return await request(buildUrl(ext.api, Object.assign({ ids: id }, ext.query)));
}

async function play(flag, id, flags) {
    if (!ext.play) {
        return '{}';
    }
    const params = Object.assign({}, ext.query, ext.params);
    params[ext.idParam || 'id'] = id;
    if (flag) params.flag = flag;
    return await request(buildUrl(ext.play, params));
}

async function search(wd, quick, pg) {
    if (ext.search === false) {
        return '{}';
    }
    return await request(buildUrl(ext.api, Object.assign({ wd: wd, quick: quick === true || quick === 'true' }, ext.query)));
}

function __jsEvalReturn() {
    return {
        init: init,
        home: home,
        homeVod: homeVod,
        category: category,
        detail: detail,
        play: play,
        search: search,
    };
}

export { __jsEvalReturn };
